function [model,DetectionResult] = FaultDiagnosisICA( train_data,train_label,test_data,test_label,Parameter)
%% ����ICA�Ĺ������  ����Ϊn * m����  nΪ���������� mΪ��������
%% ����Ԫ����a=2
%% IC,ѵ�����ݶ���Ԫ,NewIC���������ݶ���Ԫ�� I2����������ͳ������ I2_TRANS�������ݾ�����˹�任���ͳ����
%% train_dataѵ�����ݣ�test_data��������   control_limit������

confidence_bound=Parameter.confidence_bound;
MaxPolynomialNumber=Parameter.MaxPolynomialNumber;
fold=Parameter.fold;% the fold of cross validation for parameter selection    %%%%%%AQ#@$%@#$^##^$%^#@$ 2
IC_CPI=Parameter.CPI;
BiasForBoxcox=Parameter.BiasForBoxCox;
GDTmethod=Parameter.GDTmethod;

[E, D] = pcamat(train_data');    %% E--����������ͶӰ����   DΪ����ֵ����
[WhitenVectors, whitenmatrix, dewhitenmatrix] = whitenv(train_data', E, D); %%%  ��׻�����������׻������������
[IC, mixmatrix, demixmatrix] = fastica (WhitenVectors, 'approach', 'defl', 'g', 'gauss') ;%% �����Ԫ����Ͼ���ͽ�����
W=demixmatrix*whitenmatrix;

[NewWhitenVectors, whitenmatrix, dewhitenmatrix] = whitenv(test_data', E, D);%% �׻� �����д������������д���������
NewIC=demixmatrix*NewWhitenVectors;%%    ��� �����д������������д���������

% dim reduction according to the NonGaussity of independent components (CPI) and
% reorder the ICs  and corresponding matrix including demixmatrix, W,
% IC and NewIC
% first calculate Non-Gaussity
G=-exp(-IC'.^2/2);
EG=mean(G);
NonGaussity=(EG+0.707*ones(1,length(EG))).^2;
% reorder and calculate the IC numbers according to CPI
[notused,idx]=sort(NonGaussity,'descend');
cpi=0;
for i=1:length(NonGaussity)
    cpi=cpi+NonGaussity(i);
    ccpi(i)=cpi/sum(NonGaussity);
end
IC_Nums=min(find(ccpi>=IC_CPI));
% at last update the matrix
demixmatrix=demixmatrix(idx(1:IC_Nums),:);
W=demixmatrix*whitenmatrix;
NewIC=demixmatrix*NewWhitenVectors;
IC=demixmatrix*WhitenVectors;
NonGaussity=NonGaussity(idx(1:end));

%% Gaussian Distribution Transformation
[d,n]=size(IC);
train_num=floor(n/fold);
nNormData1=1:train_num;% validate-train
nNormData2=1:(n-train_num);% validate-validate
nNormData3=1:n;% test-train

sigma=1;%%%�趨����
y1=sigma*norminv((nNormData1-0.5)/train_num);
y2=sigma*norminv((nNormData2-0.5)/(n-train_num));
y3=sigma*norminv((nNormData3-0.5)/n);


CompleteingRate = waitbar(0/d,['Total number of ICs are ',num2str(d)]);
for j=1:d % IC numbers calculate for each IC
    CurrentIC=IC(j,:);
    switch GDTmethod
        case 'Polynomial'
            for k=1:fold  % fold = n, n fold cross validation to selection the parameter of polynomial order.
                rng(1000*k)
                idx1=randperm(n,train_num);
                x1=CurrentIC(idx1);
                x1=sort(x1,'ascend');
                idx2=1:n;
                idx2(idx1)=[];
                x2=CurrentIC(idx2);
                x2=sort(x2,'ascend');
                x3=sort(CurrentIC,'ascend');
                for i=1:MaxPolynomialNumber  % max polynomial order
                    p=polyfit(x1,y1,i); %save x1.mat x1,save y1.mat y1;
                    GDT_IC=polyval(p,x2);
                    GDT_IC=(GDT_IC-mean(GDT_IC))/std(GDT_IC);
                    e1=corrcoef(y2,GDT_IC);
                    e(k,i)=e1(1,2);
                end
            end
            % calculate the average correlation coefficient of n folds  for m polynomials.
            % select the polynomial order
            ee=mean(e);
            [eee,idx]=min(ee);
            Best_p(j)=idx;
            p_model{j}=polyfit(x3,y3,Best_p(j));
            TransformedIC(j,:)=polyval(p_model{j},IC(j,:));
            TransformedNewIC(j,:)=polyval(p_model{j},NewIC(j,:));
            
        case 'BoxCox'
            %% boxcox trans
            bias=BiasForBoxcox;
            CurrentIC=CurrentIC+bias;
            [z1,lambda(j)]=boxcox(CurrentIC');
            mm=mean(z1);ss=std(z1);
            TransformedIC(j,:)=boxcox(lambda(j),IC(j,:)'+bias);
            TransformedIC(j,:)=(TransformedIC(j,:)-mm)/ss;
            TransformedNewIC(j,:)=boxcox(lambda(j),NewIC(j,:)'+bias);
            TransformedNewIC(j,:)=(TransformedNewIC(j,:)-mm)/ss;
            p_model{j}=[lambda(j),mm,ss];
            %% end of boxcox   
    end
    waitbar(j/d,CompleteingRate,['Total number of ICs are ',num2str(d)]);
end
close(CompleteingRate);

% using SVDD, calculate Dist statistic and its control limit on the Independent part.
ParametersSVDD.search='off';% use the following two parameters instead of searching with algorithm
ParametersSVDD.BestKernelParameter=0.01;
ParametersSVDD.BestVParameter=0.01;
[modelSVDD,DetectionResultSVDD] = FaultDiagnosisSVDD(IC',train_label,NewIC',test_label,ParametersSVDD);


ParametersGMM.NumOfGaussianComponent=5;
ParametersGMM.ConfidenceLimit=confidence_bound;
try
    [modelGMM,DetectionResultGMM] = FaultDiagnosisGMM(IC',train_label,NewIC',test_label,ParametersGMM);
catch
    disp('GMM algorithm is not stable try second tme!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    try
        [modelGMM,DetectionResultGMM] = FaultDiagnosisGMM(IC',train_label,NewIC',test_label,ParametersGMM);
    catch
        disp('GMM algorithm is not stable try third time!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        try
            [modelGMM,DetectionResultGMM] = FaultDiagnosisGMM(IC',train_label,NewIC',test_label,ParametersGMM);
        catch
            disp('GMM algorithm is not stable try last��4�� time!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            [modelGMM,DetectionResultGMM] = FaultDiagnosisGMM(IC',train_label,NewIC',test_label,ParametersGMM);
        end
    end
end
 
% calculate I2  Inew2 IT2   ITnew2
I2=sum(IC.^2,1);
Inew2=sum(NewIC.^2,1);
IT2=sum(TransformedIC.^2,1);
ITnew2=sum(TransformedNewIC.^2,1);
% calculate their control limit.
I2c=ksdensity(I2,confidence_bound,'function','icdf');
% IT2c=ksdensity(IT2,confidence_bound,'function','icdf');
a=IC_Nums;
IT2c=a*(n-1)*(n+1)/n/(n-a)*finv(confidence_bound,a,n-a);

% monitor the residual part of the independent component.
[m,n]=size(train_data');
I=eye(m);
R=(I-W'*W)*train_data';
Rnew=(I-W'*W)*test_data';
ParametersPCA.DiagnosisStstisticType='PCA_T2&SPE';% use the following two parameters instead of searching with algorithm
ParametersPCA.confidence_bound=0.99;
ParametersPCA.PC_CPV=0.90;
ParametersPCA.VarianceNormalize='on';
% detection
[modelPCA,DetectionResultPCA] = FaultDiagnosisPCA(R',train_label,Rnew',test_label,ParametersPCA);

m=modelPCA.m;
s=modelPCA.s;
PC_Nums=modelPCA.PC_Nums;
latent=modelPCA.latent;
p=modelPCA.p;

xnew=Rnew';
n = size(xnew,1);
xnew = xnew - repmat(m,n,1);
xnew=xnew./repmat(s,n,1);

T2 = zeros(n,1);
LAMBDA=diag(latent(1:PC_Nums));
for i = 1:n
    tnew(i,1:PC_Nums)=xnew(i,:)*p(:,1:PC_Nums);    
    T2(i) = tnew(i,1:PC_Nums)*inv(LAMBDA)*tnew(i,1:PC_Nums)';
end
E_LAMBDA=diag([latent(1:PC_Nums);ones(IC_Nums,1)]);
for i = 1:n
    tnew(i,:)=xnew(i,:)*p(:,1:PC_Nums); 
    Etnew(i,:)=[tnew(i,:),TransformedNewIC(:,i)'];
    C2(i) = Etnew(i,:)*inv(E_LAMBDA)*Etnew(i,:)';
end

a=PC_Nums+IC_Nums;
C2c=a*(n-1)*(n+1)/n/(n-a)*finv(confidence_bound,a,n-a);





model.E=E;
model.D=D;
model.whitematrix=whitenmatrix;
model.demixmatrix=demixmatrix;
model.W=W;
model.NonGaussity= NonGaussity;
model.p_model=p_model;
model.IC_Nums=IC_Nums;
model.modelPCA=modelPCA;
model.modelSVDD=modelSVDD;
model.modelGMM=modelGMM;

DetectionResult.IC=IC;
DetectionResult.NewIC=NewIC;
DetectionResult.TransformedIC=TransformedIC;
DetectionResult.TransformedNewIC=TransformedNewIC;
DetectionResult.I2=I2;
DetectionResult.Inew2=Inew2;
DetectionResult.I2c=I2c;
DetectionResult.IT2=IT2;
DetectionResult.ITnew2=ITnew2;
DetectionResult.IT2c=IT2c;
DetectionResult.DetectionResultPCA=DetectionResultPCA;
DetectionResult.DetectionResultSVDD=DetectionResultSVDD;
DetectionResult.DetectionResultGMM=DetectionResultGMM;
DetectionResult.C2=C2;
DetectionResult.C2c=C2c;

DetectionResult.T2=DetectionResultPCA.Statistic;
DetectionResult.T2c=DetectionResultPCA.ControlLimit;
DetectionResult.SPE=DetectionResultPCA.Statistic2;
DetectionResult.SPEc=DetectionResultPCA.ControlLimit2;




end

