function [model,DetectionResult] = FaultDiagnosisKPCA(train_data,train_label,test_data,test_label,Parameters)
%% Fault Diagnosis using KPCA
% KPCA_FD  Summary of this function goes here
% Example: train_data=rand(1000,5);test_data=[rand(500,5);5*ones(500,5)];test_label=[zeros(500,1);ones(500,1)]; ACC = KPCA_FD( train_data,test_data,test_label,8);
% Example :close all;clear;t=randn(1000,1);train_data=[t,t.^2+0.5*randn(length(t),1)];t=randn(1000,1);test_data=[t,t.^2+0.5*randn(length(t),1)];test_data=test_data+[zeros(600,2);5*ones(400,2)];test_label=[-1*ones(600,1);ones(400,1)]; [cMat] = KPCA_FD( train_data,test_data,test_label,200)
%% train 1.KPCA decomposition of train_data,
DiagnosisStstisticType=Parameters.DiagnosisStstisticType;
sigma=Parameters.BestKernelParameter; %8.9;
PC_CPV=Parameters.PC_CPV;
confidence_bound=Parameters.confidence_bound;
[DoNotUseThisLambda,alpha,K]=KernelPCA(train_data,sigma);
m=size(train_data,1);
In=ones(m,m)/m;
K_n=K-In*K-K*In+In*K*In;

% score=K_n*alpha;
% D=score.^2;
% lambda=diag(sum(D)/m);%%%this is improtant , two different lambda!!!!! this lambda is the variance of Kennel principal component, but not the one returned from SVD(K_n/m)
% % as it can be dierived mathmatically that lambda=DoNotUseThisLambda*m;
% % DoNotUseThisLambda is the lambda from SVD(K_n/m)
% lambda=DoNotUseThisLambda*m;
% % save socre.mat score; save lambda.mat lambda;save alpha.mat alpha;save K_n.mat K_n; save DoNotUseThisLambda.mat DoNotUseThisLambda;

% 2018/7/9 neweast eqution in thesis paper proved that sigma=lambda so,
lambda=DoNotUseThisLambda;
score=K_n*alpha;

%% train 2. find PCs
cpv=0;
for i=1:size(lambda,1)
    cpv=cpv+lambda(i,i);
    ccpv(i)=cpv/sum(diag(lambda));
end
PC_Nums=min(find(ccpv>=PC_CPV));

%% train 3.calculate T2 of train data
for i=1:size(score,1)
    T2_train(i)=score(i,1:PC_Nums)/lambda(1:PC_Nums,1:PC_Nums)*score(i,1:PC_Nums)';
end

% SPE of train data
M=alpha(:,1:PC_Nums)*alpha(:,1:PC_Nums)';
Q_train=diag(K_n-2*K_n*M*K_n+K_n*M*K_n*M*K_n);

%% train 4. calculate control limit using KDE method.
T2c=ksdensity(T2_train,confidence_bound,'function','icdf');
Qc=ksdensity(Q_train,confidence_bound,'function','icdf');
save T2_train.mat T2_train
%% test 1.calculate new gramm vecter

Knew=MyGaussianKernel( train_data,test_data,sigma );

%% test 2.centralization
n=size(test_data,1);
[m,VarNum]=size(train_data);
In=ones(m,m)/m;
Innew=ones(m,n)/m;
K_new=Knew-In*Knew-K*Innew+In*K*Innew;
%% test 3.calculate new T
score_new=K_new'*alpha;
for i=1:size(score_new,1)
    T2(i)=score_new(i,1:PC_Nums)/lambda(1:PC_Nums,1:PC_Nums)*score_new(i,1:PC_Nums)';
end
%% calculat the Q and its control limit
% calculate the new kernel matrix
Kff=MyGaussianKernel( test_data,test_data,sigma );
% centralization
n=size(test_data,1);
[m,VarNum]=size(train_data);
In=ones(m,m)/m;
Innew=ones(m,n)/m;
K_ff=Kff-Knew'*Innew-Innew'*Knew+Innew'*K*Innew;
% calculate Q
Q=diag(K_ff-2*K_new'*M*K_new+K_new'*M*K_n*M*K_new);

%% calculate acc
% Calculate the accuracy of T2
SignOfNegative=1;
SignOfPositive=-1;
T2Negative=T2(find(test_label==SignOfNegative));
T2Positive=T2(find(test_label==SignOfPositive));
TrueT2=(length(find(T2Negative<=T2c))+length(find(T2Positive>T2c)) );
TandP_T2=length(T2);
T2ACC=TrueT2/TandP_T2;
disp(['Accuracy of Kernel T^2 ststistic = ',num2str(T2ACC*100),'% (',num2str(TrueT2),'/',num2str(TandP_T2),') (classification)'])
% Calculate the accuracy of SPE
SPE_Negative=Q(find(test_label==SignOfNegative));
SPE_Positive=Q(find(test_label==SignOfPositive));
True_SPE=(length(find(SPE_Negative<=Qc))+length(find(SPE_Positive>Qc)) );
TandP_SPE=length(Q);
Q_ACC=True_SPE/TandP_SPE;
switch DiagnosisStstisticType
    case 'KPCA_T2&SPE'
        disp(['Accuracy of Kernel SPE ststistic = ',num2str(Q_ACC*100),'% (',num2str(True_SPE),'/',num2str(TandP_SPE),') (classification)'])
    case 'KPCA_T2'
        disp(['SPE is not calculated (classification)'])
end

%% reture the results
model.K=K;
model.PC_Nums=PC_Nums;
model.alpha=alpha;
model.lambda=lambda;
model.VarNum=VarNum;
model.sigma=sigma;
model.train_data=train_data;

DetectionResult.Statistic=T2';
DetectionResult.Statistic2=Q;
DetectionResult.ControlLimit=T2c;
DetectionResult.ControlLimit2=Qc;
DetectionResult.m=zeros(1,size(train_data,2));%only used in PCA FD



% figure;hold on
% plot(T2_train,'b')
% plot(T2,'g')
% line([0,length(DetectionResult.Statistic)],[DetectionResult.ControlLimit,DetectionResult.ControlLimit],'LineStyle','- -','Color','r','linewidth',2),



end

