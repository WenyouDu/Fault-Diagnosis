function [train_data,train_label,test_data,test_label]= PrepareData(DatasetConfig)
%% prepare detaset
DatasetIndex=DatasetConfig.DatasetIndex;
k=DatasetConfig.TrainDataNumber;
CentralizationOption=DatasetConfig.CentralizationOption;
FaultMagnitude=DatasetConfig.FaultMagnitude;
NormalizationOption=DatasetConfig.NormalizationOption;
switch DatasetIndex
    case 1  % synthetic dataset including 10 independent gaussian distributed variables
        n=1000;
        m=10;
        NumOfEachFault=40;
        X=randn(n,m);
        train_data=X(1:k,:);
        train_label=ones(k,1);
        for i=1:m
            X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+5*ones(NumOfEachFault,1);
        end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
    case 2  % multi-mode data  i.e. gaussian mixture model
        mu1 = [6 0];
        Sigma1 = [1 0 ; 0 1];
        mu2 = [-6 0];
        Sigma2 = [1 0 ; 0 1];
        mu3 = [6 12];
        Sigma3 = [1 0 ; 0 1];
        %rng('shuffle'); % For reproducibility
        %rng(1)
        M=round(k/3);N=round(k/3);P=k-M-N;
        m=2;
        train_data=[mvnrnd(mu1,Sigma1,M);mvnrnd(mu2,Sigma2,N);mvnrnd(mu3,Sigma3,P)];
        train_label=ones(k,1);
        
        NumOfEachFault=200;
        M=round(NumOfEachFault/3);N=round(NumOfEachFault/3);P=NumOfEachFault-M-N;
        X1=[mvnrnd(mu1,Sigma1,M);mvnrnd(mu2,Sigma2,N);mvnrnd(mu3,Sigma3,P)];
        X2=[mvnrnd(mu1,Sigma1,M);mvnrnd(mu2,Sigma2,N);mvnrnd(mu3,Sigma3,P)];
        %         X3=[mvnrnd(mu1,Sigma1,M);mvnrnd(mu2,Sigma2,N);mvnrnd(mu3,Sigma3,P)];
        X2(:,1)=X2(:,1)-FaultMagnitude*[ones(M,1);ones(N,1);2*ones(P,1)];
        %         X3(:,2)=X3(:,2)-FaultMagnitude*ones(NumOfEachFault,1);
        test_data=[X1;X2];
        test_label=[1*ones(NumOfEachFault,1);-1*ones(NumOfEachFault,1)];
        
    case 3  % non-linear realationship  i.e. two dimensional banana
        n=600;m=2;NumOfEachFault=200;
        rr=rand(n,1);
        theta=2/4*pi*(rr-min(rr))/(max(rr)-min(rr));
        r=8+rand(n,1);
        x1=[r.*cos(theta)];
        y1=[r.*sin(theta)];
        %scatter(x1,y1,'.')
        X=[x1,y1];
        label=ones(n,1);
        train_data=X(1:k,:);
        train_label=label(1:k);
        for i=1:m
            X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+m*(1.5-i)*FaultMagnitude*ones(NumOfEachFault,1);
        end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
        
    case 4  % the dataset proposed by Qin 2003(Statistical process monitoring: basics and beyond,example 2 sensor fault)
        n=1000;
        m=4;
        NumOfEachFault=40;
        X=randn(n,m)*[1 0 0 0;0 0.8 0 0; 0 0 0 0;0 0 0 0 ]*[0.3873 -0.1291 0.9037 0.1291 ;0.1190 0.2379 -0.1530 0.9518;0 0 0 0;0 0 0 0]+0.2*randn(n,m);
        train_data=X;
        train_label=ones(n,1);
        for i=1:m
            X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+2*ones(NumOfEachFault,1);
        end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
        StdOfTrainData=std(train_data)
    case 5 % shuttle dataset obtained from http://odds.cs.stonybrook.edu/
        Data=load('./DataSet/shuttle.mat');
        NormalData=Data.X;NormalData(Data.y==1,:)=[];
        FaultData=Data.X;FaultData(Data.y==0,:)=[];
        NumOfNormalTrain=1000;
        NumOfNormalTest=300;
        NumOfFaultTest=300;
        %rng(1)
        train_data=NormalData(randperm(size(NormalData,1),NumOfNormalTrain),:);
        train_label=ones(NumOfNormalTrain,1);
        test_data=[NormalData(randperm(size(NormalData,1),NumOfNormalTest),:);...
            FaultData(randperm(size(FaultData,1),NumOfFaultTest),:)];
        test_label=[ones(NumOfNormalTest,1);-1*ones(NumOfFaultTest,1)];
    case 6 % shuttle dataset obtained from http://odds.cs.stonybrook.edu/
        Data=load('./DataSet/annthyroid.mat');
        NormalData=Data.X;NormalData(Data.y==1,:)=[];
        FaultData=Data.X;FaultData(Data.y==0,:)=[];
        NumOfNormalTrain=1000;
        NumOfNormalTest=300;
        NumOfFaultTest=300;
        %rng(1)
        train_data=NormalData(randperm(size(NormalData,1),NumOfNormalTrain),:);
        train_label=ones(NumOfNormalTrain,1);
        test_data=[NormalData(randperm(size(NormalData,1),NumOfNormalTest),:);...
            FaultData(randperm(size(FaultData,1),NumOfFaultTest),:)];
        test_label=[ones(NumOfNormalTest,1);-1*ones(NumOfFaultTest,1)];
    case 7  % non-linear realationship  i.e. quadratic curve
        n=600;m=2;NumOfEachFault=200;
        rr=1*rand(n,1);
        x1=rr.^2+0.05*randn(n,1);
        y1=rr+0.05*randn(n,1);
        %scatter(x1,y1,'.')
        X=[x1,y1];
        label=ones(n,1);
        train_data=X(1:k,:);
        train_label=label(1:k);
        for i=1:m
            X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+m*(1.5-i)*FaultMagnitude*ones(NumOfEachFault,1);
        end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
    case 8    %TE process chiang's data  fault 1
        [ TE_TrainDataSet, TE_TestDataSet,TE_TrainDataSetLabel,TE_TestDataSetLabel] = ReadTE_Data( );
        train_data=TE_TrainDataSet.d00;
        train_label=TE_TrainDataSetLabel.d00;
        test_data=TE_TestDataSet.d01_te;
        test_label=TE_TestDataSetLabel.d01_te;
    case 9   % TE process ricker's data fault1
        % use the TEC mdl simulink model to get data;save the data using
        % this command: fault?=[xmeas(2:end,:),xmv(2:end,1:11)];save ./GeneratedData/Mode1/Train/fault?.mat fault?
        Generated_train_data=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_test_data=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/fault1.mat')));
        train_data=Generated_train_data(1:480,[1:45,47:49,51:52]);% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 10 %
        
    case 11  %for thesis figure 1-1
        m=2;
        train_data=randn(k,m)*eye(m);
        train_label=ones(k,1);
        test_data=randn(k,m)*eye(m);
        test_label=ones(k,1);
    case 12  %for thesis figure 1-2
        m=2;
        train_data=randn(k,m)*[1,0;0,2];
        train_label=ones(k,1);
        test_data=randn(k,m)*[1,0;0,2];
        test_label=ones(k,1);
    case 13  %for thesis figure 1-3
        m=2;
        train_data=randn(k,m)*[1,0;0,2]*[sqrt(2)/2,sqrt(2)/2;sqrt(2)/2,-sqrt(2)/2];
        train_label=ones(k,1);
        test_data=randn(k,m)*[1,0;0,2]*[sqrt(2)/2,sqrt(2)/2;sqrt(2)/2,-sqrt(2)/2];
        test_label=ones(k,1);
    case 14  %for thesis figure 2
        m=2;
        train_data=randn(k,m)*[1,0;0,2]*[sqrt(2)/2,sqrt(2)/2;sqrt(2)/2,-sqrt(2)/2]+5*ones(k,m);
        train_label=ones(k,1);
        test_data=randn(k,m)*[1,0;0,2]*[sqrt(2)/2,sqrt(2)/2;sqrt(2)/2,-sqrt(2)/2];
        test_label=ones(k,1);
    case 15 % train:mode1 and mode3  multimode dataset of TE process  test: mode1 fault1
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault1.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault1.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode1(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 16 % train:mode1 and mode3  multimode dataset of TE process  test: mode3 fault1
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault1.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault1.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode3(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 17 % train:mode1 and mode3  multimode dataset of TE process  test: mode1 fault4
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault4.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault4.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode1(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 18 % train:mode1 and mode3  multimode dataset of TE process  test: mode3 fault4
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault4.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault4.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode3(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 19 % train:mode1 and mode3  multimode dataset of TE process  test: mode1 fault4
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault11.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault11.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode1(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
    case 20 % train:mode1 and mode3  multimode dataset of TE process  test: mode3 fault4
        % use the TEC mdl simulink model to get data;save the data using DataSaveCommand.m
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault11.mat')));
        Generated_test_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault11.mat')));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=Generated_test_data_mode3(:,[1:45,47:49,51:52]);
        test_label=[ones(size(test_data,1)/6,1);-1*ones(5*size(test_data,1)/6,1)];
        
    case 50  % synthetic dataset including 10 independent gaussian distributed variables
        n=2000;
        m=6;
        NumOfEachFault=100;
        A=[-0.2310,-0.3241 -0.2170,-0.4089,-0.6405,-0.4655;...
            -0.0816,0.7055, -0.3056,-0.3442, 0.3102,-0.4330;...
            -0.2662,-0.2158,-0.5207,-0.4501, 0.2372, 0.5938];
        noise=0.2*randn(n,6);
        X=randn(n,3)*A+noise;
        train_data=X(1:k,:);
        train_label=ones(k,1);
        for i=1:m
            X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+FaultMagnitude*ones(NumOfEachFault,1);
        end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
    case 501  % synthetic dataset including 10 independent gaussian distributed variables
        n=2000;
        m=6;
        NumOfEachFault=100;
        A=[-0.2310,-0.3241 -0.2170,-0.4089,-0.6405,-0.4655;...
            -0.0816,0.7055, -0.3056,-0.3442, 0.3102,-0.4330;...
            -0.2662,-0.2158,-0.5207,-0.4501, 0.2372, 0.5938];
        noise=0.2*randn(n,6);
        X=randn(n,3)*A+noise;
        train_data=X(1:k,:);
        train_label=ones(k,1);
        %         for i=1:m
        %             X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)=X(i*NumOfEachFault+1:(i+1)*NumOfEachFault,i)+FaultMagnitude*ones(NumOfEachFault,1);
        %         end
        test_data=X(1:NumOfEachFault*(m+1),:);
        test_label=[1*ones(NumOfEachFault*1,1);-1*ones(NumOfEachFault*m,1)];
        
    case 502
        m=10;
        train_data=[randn(200,m);[randn(200,m)-[0*ones(200,2),10*ones(200,1),0*ones(200,7)];randn(200,m)-[0*ones(200,1),10*ones(200,1),0*ones(200,8)]]]+0.2*randn(600,m);
        train_label=[ones(200,1);2*ones(200,1);3*ones(200,1)];
        test_data=[randn(200,m);...
            [randn(200,m)-[0*ones(200,2),10*ones(200,1),0*ones(200,7)];...
            randn(200,m)-[0*ones(200,1),10*ones(200,1),0*ones(200,8)]]]+0.2*randn(600,m);
        test_label=[];
    case 503
        n=1000;
        normal=3*(rand(n,1)-0.5);
        x1=normal+0.2*randn(n,1);
        y1=normal.^2+0.2*randn(n,1);
        fault1=3*(rand(n,1)-0.5)+2*ones(n,1);
        x2=fault1+0.2*randn(n,1);
        y2=2*fault1.^2+0.2*randn(n,1);
        fault2=3*(rand(n,1)-0.5)+2*ones(n,1);
        x3=fault2+0.2*randn(n,1);
        y3=fault2.^2+0.2*randn(n,1);
        
        train_data=[x1(1:100),y1(1:100);x2(1:100),y2(1:100);x3(1:100),y3(1:100);];
        train_label=[ones(100,1);2*ones(100,1);3*ones(100,1)];
        
        test_data=[x1(101:200),y1(101:200);x2(101:200),y2(101:200);x3(101:200),y3(101:200);];
        test_label=[ones(100,1);2*ones(100,1);3*ones(100,1)];
    case 504
        m=5;magnitude=10; modedis=10;
        train_data=[randn(100,m);randn(100,m)+modedis*ones(100,m);...
            randn(200,m)+0*ones(200,m)-[magnitude*ones(200,1),0*ones(200,4)];...
            randn(200,m)+modedis*ones(200,m)+[0*ones(200,1),magnitude*ones(200,1),0*ones(200,3)]]+0.01*randn(600,m);
        %         train_data=[randn(100,m);randn(100,m)+0*ones(100,m);[randn(200,m)-[0*ones(200,2),10*ones(200,1),0*ones(200,7)];randn(200,m)-[0*ones(200,1),10*ones(200,1),0*ones(200,8)]]]+0.2*randn(600,m);
        train_label=[ones(200,1);2*ones(200,1);3*ones(200,1)];
        test_data=[randn(100,m);randn(100,m)+modedis*ones(100,m);...
            randn(200,m)+0*ones(200,m)-[magnitude*ones(200,1),0*ones(200,4)];...
            randn(200,m)+modedis*ones(200,m)+[0*ones(200,1),magnitude*ones(200,1),0*ones(200,3)]]+0.01*randn(600,m);
        %         test_data=randn(600,m);
        test_label=[];
    case 505
        [ TE_TrainDataSet, TE_TestDataSet,TE_TrainDataSetLabel,TE_TestDataSetLabel] = ReadTE_Data( );
        train_data=[];
        train_label=[];
        test_data=[];
        test_label=[];
        train_data=[...
            TE_TrainDataSet.d00;...
            TE_TrainDataSet.d01;...
            TE_TrainDataSet.d02;...
            TE_TrainDataSet.d04;...
            TE_TrainDataSet.d05;...
            ];
        
        train_label=[...
            TE_TrainDataSetLabel.d00;...
            -2*TE_TrainDataSetLabel.d01;...
            -3*TE_TrainDataSetLabel.d02;...
            -4*TE_TrainDataSetLabel.d04;...
            -5*TE_TrainDataSetLabel.d05;...
            ];
        
        test_data=[...
            TE_TestDataSet.d02_te;...
            ];
        test_label=[...
            -2*TE_TestDataSetLabel.d02_te;...
            
            ];
        %         test_data=train_data;
        %         test_label=train_label;
    case 301   %TE process chiang's data  fault k
        [ TE_TrainDataSet, TE_TestDataSet,TE_TrainDataSetLabel,TE_TestDataSetLabel] = ReadTE_Data( );
        train_data=TE_TestDataSet.d00_te;
        train_label=TE_TestDataSetLabel.d00_te;
        str=num2str(k);
        if k<10
            str=['0',str];
        end
        eval(['test_data=TE_TestDataSet.d',str,'_te;'])
        eval(['test_label=TE_TestDataSetLabel.d',str,'_te;'])
    case 302   %TE process ricker's data  fault k
        rng(1)
        str=num2str(k);
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_train_data_mode3=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault',str,'.mat'])));
        Generated_test_data_mode3=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode3/Test/fault',str,'.mat'])));
        train_data=[Generated_train_data_mode1(1:480,[1:45,47:49,51:52]);Generated_train_data_mode3(1:480,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=[Generated_test_data_mode1(:,[1:45,47:49,51:52]);Generated_test_data_mode3(:,[1:45,47:49,51:52])];
        if k~=6
            test_label=[ones(size(Generated_test_data_mode1,1)/6,1);-1*ones(5*size(Generated_test_data_mode1,1)/6,1);...
                ones(size(Generated_test_data_mode3,1)/6,1);-1*ones(5*size(Generated_test_data_mode3,1)/6,1)];
        else
            test_label=[ones(160,1);-1*ones(142,1);ones(160,1);-1*ones(124,1)];
        end
        NormalDataInFaultSet=[];
        if FaultMagnitude=='MoreNormalData'
            for ff=1:28
                str2=num2str(ff);
                Generated_test_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/fault',str2,'.mat'])));
                Generated_test_data_mode3=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/fault',str2,'.mat'])));
                NormalDataInFaultSet=[NormalDataInFaultSet;Generated_test_data_mode1(1:160,:);Generated_test_data_mode3(1:160,:)];
            end
            %  save NormalDataInFaultSet.mat  NormalDataInFaultSet
            NormalDataInFaultSet=[NormalDataInFaultSet(:,[1:45,47:49,51:52]);train_data];
            train_data=NormalDataInFaultSet(randperm(9920,1000),:);
            train_label=ones(size(train_data,1),1);
        end
    case 'ICA_Test'
        rng(100),A=randn(2,10);
        train_data=rand(480,2)*A+0.5*randn(480,10);
        train_label=ones(size(train_data,1),1);
        rng(10000)
        test_data=rand(960,2)*A+0.5*randn(960,10);
        fault=3*ones(960,10);
        fault(:,1:8)=0*fault(:,1:8);
        fault(1:160,9:10)=0*fault(1:160,9:10);
        test_data=test_data+fault;
        test_label=ones(size(test_data,1),1);
        
    case 303   %TE process ricker's data  fault k
        rng(1000)
        str=num2str(k);
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_test_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/fault',str,'.mat'])));
        
        train_data=Generated_train_data_mode1(:,[1:45,47:49,51:52]);% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        test_data=[Generated_test_data_mode1(:,[1:45,47:49,51:52])];
        if k==6
            test_label=[ones(160,1);-1*ones(142,1)];
        elseif k==29
            test_label=ones(size(test_data,1),1);    
        else
            test_label=[ones(size(Generated_test_data_mode1,1)/6,1);-1*ones(5*size(Generated_test_data_mode1,1)/6,1)]; 
        end
        
%         NormalDataInFaultSet=[];
%         if FaultMagnitude=='MoreNormalData'
%             for ff=1:28
%                 str2=num2str(ff);
%                 Generated_test_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/fault',str2,'.mat'])));
%                 %                 Generated_test_data_mode3=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/fault',str2,'.mat'])));
%                 NormalDataInFaultSet=[NormalDataInFaultSet;Generated_test_data_mode1(1:160,:)];
%             end
%             NormalDataInFaultSet=[NormalDataInFaultSet(:,[1:45,47:49,51:52]);train_data];
%             train_data=NormalDataInFaultSet(randperm(4960,1000),:);
%             train_label=ones(size(train_data,1),1);
%         end
    case 304   %TE process chiang's data  fault k
%         rng(3000)
        [ TE_TrainDataSet, TE_TestDataSet,TE_TrainDataSetLabel,TE_TestDataSetLabel] = ReadTE_Data( );        
        train_data=TE_TrainDataSet.d00;
        train_label=TE_TrainDataSetLabel.d00;
%         NormalDataInFaultSet=TE_TrainDataSet.d00;
%         if FaultMagnitude=='MoreNormalData'
%             for ff=1:21
%                 str=num2str(ff);
%                 if ff<10
%                     str=['0',str];
%                 end
%                 eval(['NormalDataInFaultSet=[NormalDataInFaultSet; TE_TrainDataSet.d',str,'(1:20,:)];'])
%             end
% 
%             train_data=NormalDataInFaultSet(randperm(900,480),:);
%             train_label=ones(size(train_data,1),1);
%         end
        
        switch k
            case 1
                test_data=train_data;
                test_label=train_label;
            case 2
                test_data=TE_TestDataSet.d00_te;
                test_label=TE_TestDataSetLabel.d00_te;
        end
        A=train_data;B=train_label;
        train_data=test_data;train_label=test_label;
        test_data=A;test_label=B;
    case 305   %TE process ricker's data  fault k
        rng(1000)
        Generated_train_data_mode1=cell2mat(struct2cell(load('./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/normal.mat')));
        Generated_test_normal_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Test/normal.mat'])));
        train_data=[Generated_train_data_mode1(1:960,[1:45,47:49,51:52])];% the 46, 50 variables are the 5-th and 9-th xmv ,they are not controlled in the simulink model and will not be used for fault diagnosis, just like the 12-th xmv was not used in chiang's book.
        train_label=ones(size(train_data,1),1);
        NormalDataInFaultSet=[];
%         if FaultMagnitude=='MoreNormalData'
%             for ff=1:28
%                 str2=num2str(ff);
%                 Generated_test_data_mode1=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode1/Train/fault',str2,'.mat'])));
%                 %                 Generated_test_data_mode3=cell2mat(struct2cell(load(['./DataSet/TE/temexd_mod/GeneratedData/Mode3/Train/fault',str2,'.mat'])));
%                 NormalDataInFaultSet=[NormalDataInFaultSet;Generated_test_data_mode1(1:160,:)];
%             end
%             NormalDataInFaultSet=[NormalDataInFaultSet(:,[1:45,47:49,51:52]);train_data];
%                         save NormalDataInFaultSet.mat NormalDataInFaultSet
%             train_data=NormalDataInFaultSet(randperm(4960,480),:);
%             train_label=ones(size(train_data,1),1);
%         end 
        switch k
            case 1
                test_data=train_data;
                test_label=ones(size(test_data,1),1); 
            case 2
                test_data=[Generated_test_normal_data_mode1(:,[1:45,47:49,51:52])];
                test_label=ones(size(test_data,1),1); 
        end  
        
        
end



% choose to centralize or not
switch CentralizationOption
    case 'on'
        [notused,m] = Centralization(train_data(train_label==1,:));% centralization: subtract the mean value of train_data from train_data
        [train_data] = Centralization(train_data,m);
        [test_data] = Centralization(test_data,m);% centralization: substract the mean value of train_data from test_data
        disp('dataset is centralized')
    case 'off'
        disp('dataset is not centralized')
end
switch NormalizationOption
    case 'on'
        [notused,s] = VarianceNormalization(train_data(train_label==1,:));% VarianceNormalization�� divide the train_data by the standard variance value of train_data
        [train_data] = VarianceNormalization( train_data,s);
        [test_data] = VarianceNormalization( test_data,s);% VarianceNormalization�� divide the test_data by the standard variance value of train_data        disp('dataset is centralized')
        disp('dataset is normalized')
    case 'off'
        disp('dataset is not normalized')
end

end