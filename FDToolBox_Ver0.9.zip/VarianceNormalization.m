function [ x,s ] = VarianceNormalization(x,s)
% divide the standard value
% ����׼��
switch nargin
    case 1
        s = std(x)+eps*randn(1,size(x,2));
        n = size(x,1);
        x = x./repmat(s,n,1);
    case 2
        n = size(x,1);
        x = x./repmat(s,n,1);
        
end

end

