function [model,DetectionResult] = FaultDiagnosisGMM(train_data,train_label,test_data,test_label,Parameters)
%% Fault detection Using a Gaussian Mixture Model
%% Developed by Wenyou Du, 2018/09/19.

NumOfGaussianComponent=Parameters.NumOfGaussianComponent;
ConfidenceLimit=Parameters.ConfidenceLimit;

[n,~]=size(train_data);% n samples and m variables

% Fit a Gaussian mixture model.  Specify that there are two components(gaussian component).
GMModel = fitgmdist(train_data,NumOfGaussianComponent);

% NLP of train data
T=pdf(GMModel,train_data);
NegativeLogPdf=-log10(T);

% calculate the control limit
[NegativeLogPdfForControlLimit,~]=sort(NegativeLogPdf,'Ascend');
ControlLimit=NegativeLogPdfForControlLimit(round(ConfidenceLimit*n));

%% predict
Tnew=pdf(GMModel,test_data);
Tnew(find(Tnew==0))=min(Tnew(find(Tnew~=0)));
NLP_Predict=-log10(Tnew);


% Calculate the accuracy of NLP
T2=NLP_Predict;
T2c=ControlLimit;
SignOfNegative=1;
SignOfPositive=-1;
T2Negative=T2(find(test_label==SignOfNegative));
T2Positive=T2(find(test_label==SignOfPositive));
TrueT2=(length(find(T2Negative<=T2c))+length(find(T2Positive>T2c)) );
TandP_T2=length(T2);
T2ACC=TrueT2/TandP_T2;
disp(['Accuracy of NLP ststistic = ',num2str(T2ACC*100),'% (',num2str(TrueT2),'/',num2str(TandP_T2),') (classification)'])

% return results
model.NumOfGaussianComponent=NumOfGaussianComponent;
model.GMModel=GMModel;

DetectionResult.NLP_Predict=NLP_Predict;
DetectionResult.ControlLimit=ControlLimit;


%% two-dimensional control limit and scatter of data.
% h1=fimplicit(@(x1, x2) -log10(pdf(GMModel,[x1 x2]))-control_limit,[-5 8 -1 8]);
% title('{\bf Scatter Plot and Fitted Gaussian Mixture Contours}')
% legend(h,'Model 0','Model1')

% [ntest,~]=size(test_data);
% figure; 
% hold on;
% plot(NLP_Predict);
% plot(NegativeLogPdf,'r')
% line([0 ntest],[ControlLimit ControlLimit]);
% hold off

end

%% ��GMMʵ�ֶ�����࣬ ����Ԥ��ֵ�� ����posterior�������������ʡ�
%% classification using GMM, calculate the predict value, calculate the posterior probability.
%% Component was asigned as 3.
% P = posterior(GMModel,test_data);
% n = size(X,1);
% [~,order] = sort(P(:,1));
% figure
% plot(1:n,P(order,1),'r-',1:n,P(order,2),'b-',1:n,P(order,3),'g-')
% legend({'Cluster 1', 'Cluster 2','Cluster 3'})
% ylabel('Cluster Membership Score')
% xlabel('Point Ranking')
% title('GMM with Full Unshared Covariances')
