function [ back ] =KPCAcontour( x,y ,data)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
m=data.m;train_data=data.data;t=data.t;K=data.K;trac=data.trac;
vec=data.vec;p=data.p;T2c=data.T2c;

test_data=[x,y];
n=size(test_data,1);
Knew=zeros(m,n);
for i=1:m
    for j=1:n
    Knew(i,j)=exp(-(norm(train_data(i,:)-test_data(j,:)).^2)/t);
    end
end
%% test 2.centralization
In=ones(m,m)/m;
Innew=ones(m,n)/m;
K_1=Knew-In*Knew-K*Innew+In*K*Innew;
K_n=K_1/trac;
%% test 3.calculate new T
T_new=K_n'*vec;
T_matrix=T_new(:,1:p);

for i=1:size(T_matrix,1)
Tnew2(i)=T_matrix(i,:)*T_matrix(i,:)';
end
back=Tnew2-T2c*ones(length(Tnew2),1);
% back=T_matrix(:,2)-T2c;
end

