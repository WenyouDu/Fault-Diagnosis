    %TE process chiang's data  fault k
    DatasetConfig.DatasetIndex=301;% assign dataset
    DatasetConfig.TrainDataNumber=1;% not used
    DatasetConfig.FaultMagnitude=3;% not used
    DatasetConfig.CentralizationOption='on';% wether centralize the dataset
    DatasetConfig.NormalizationOption='on';% wether normalize the dataset
    [train_data,train_label,test_data,test_label]= PrepareData(DatasetConfig);