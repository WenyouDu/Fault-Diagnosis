% Add all folders and subfolders to the working directory
% Fault Detection using Chiang's Dataset
% there are total 21 faults in Chiang's Dataset.
clc,clear,close all
for i=1:21
    
    
    DatasetConfig.DatasetIndex=301;% assign dataset
    DatasetConfig.TrainDataNumber=i;% not used
    DatasetConfig.FaultMagnitude=3;% not used
    DatasetConfig.CentralizationOption='on';% wether centralize the dataset
    DatasetConfig.NormalizationOption='on';% wether normalize the dataset
    [train_data,train_label,test_data,test_label]= PrepareData(DatasetConfig);
    
    
     %% PCA fault detection
    % set parameters
    Parameters.DiagnosisStstisticType='PCA_T2&SPE';% use the following two parameters instead of searching with algorithm
    Parameters.confidence_bound=0.99;
    Parameters.PC_CPV=0.95;
    Parameters.VarianceNormalize='on';
    % detection
    [model,DetectionResult] = FaultDiagnosisPCA(train_data,train_label,test_data,test_label,Parameters);
    ResultPCA{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.Statistic),1);
    idx_FaultT2=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.Statistic),1);
    idx_FaultSPE=find(DetectionResult.Statistic2>DetectionResult.ControlLimit2);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedPCA_PredictLabel=(DetectionResult.Statistic2>DetectionResult.ControlLimit2)|(DetectionResult.Statistic>DetectionResult.ControlLimit);
    idx_NormalIntegratedPCA=find(IntegratedPCA_PredictLabel==0);   
    idx_FaultIntegratedPCA=find(IntegratedPCA_PredictLabel==1);
    PredictedLabelPCA_Total(idx_NormalIntegratedPCA)=1;
    PredictedLabelPCA_Total(idx_FaultIntegratedPCA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelPCA_Total );
    options=[];
    ResultT2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixT2{i}, options );
    ResultSPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixSPE{i}, options );
    ResultintegratedPCA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixPCA{i}, options );
    
    %% KPCA Fault Detection
    % set the parameters
    
    Parameters.DiagnosisStstisticType='KPCA_T2&SPE';% use the following two parameters instead of searching with algorithm
    Parameters.confidence_bound=0.999;
    Parameters.PC_CPV=0.95;
    Parameters.BestKernelParameter=10^(-4);
    % detection
    [model,DetectionResult] = FaultDiagnosisKPCA(train_data,train_label,test_data,test_label,Parameters);
    ResultKPCA{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.Statistic),1);
    idx_FaultT2=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.Statistic),1);
    idx_FaultSPE=find(DetectionResult.Statistic2>DetectionResult.ControlLimit2);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedPCA_PredictLabel=(DetectionResult.Statistic2>DetectionResult.ControlLimit2)|(DetectionResult.Statistic>DetectionResult.ControlLimit);
    idx_NormalIntegratedPCA=find(IntegratedPCA_PredictLabel==0);   
    idx_FaultIntegratedPCA=find(IntegratedPCA_PredictLabel==1);
    PredictedLabelPCA_Total(idx_NormalIntegratedPCA)=1;
    PredictedLabelPCA_Total(idx_FaultIntegratedPCA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixKernelT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixKernelSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixKernelPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelPCA_Total );
    options=[];
    ResultKernelT2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelT2{i}, options );
    ResultKernelSPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelSPE{i}, options );
    ResultintegratedKernelPCA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelPCA{i}, options );
    
    
   
    
    %% OC-SVM fault detection
    % set parameters
    Parameters.search='off';% use the following two parameters instead of searching with algorithm
    Parameters.BestKernelParameter=0.0001;
    Parameters.BestVParameter=0.01;
    % detection
    [model,DetectionResult] = FaultDiagnosisSVDD(train_data,train_label,test_data,test_label,Parameters);
    ResultOCSVM{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelD=ones(length(DetectionResult.Statistic),1);
    idx_FaultD=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelD(idx_FaultD)=2;
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixD{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelD );
    options=[];
    ResultD{i}  = CalculateEvaluationIndicator(  ConfusionMatrixD{i}, options );
    
    
%     %% whitening OC-SVM fault detection
%     % set parameters
%     Parameters.search='off';% use the following two parameters instead of searching with algorithm
%     Parameters.BestKernelParameter=0.01;
%     Parameters.BestVParameter=0.01;
%     % whitening
%     C=(1/(size(train_data,1)-1))*train_data'*train_data;
%     [U,D,V]=svd(C);
%     dim=48;
%     train_data=train_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
%     test_data=test_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
%     % detection
%     [model,DetectionResult] = FaultDiagnosisSVDD(train_data,train_label,test_data,test_label,Parameters);    
%     ResultOCSVM{i}=DetectionResult;
%     % evaluation, prepare labels
%     idx_normal=find(test_label==1);
%     idx_fault=find(test_label~=1);
%     GroundTruthLabel(idx_normal)=1;
%     GroundTruthLabel(idx_fault)=2;
%     
%     PredictedLabelD=ones(length(DetectionResult.Statistic),1);
%     idx_FaultD=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
%     PredictedLabelD(idx_FaultD)=2;
%     % evaluation ,calculate ConfusionMatrix and FAR and MAR
%     ConfusionMatrixD_Whitening{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelD );
%     options=[];
%     ResultD_Whitening{i}  = CalculateEvaluationIndicator(  ConfusionMatrixD{i}, options );
    
    
    
    disp(i)
    
end
for i=1:21
    TableFAR(i,1)=ResultT2{i}.error(1);
    TableFAR(i,2)=ResultSPE{i}.error(1);
    TableFAR(i,3)=ResultintegratedPCA{i}.error(1);
    TableFAR(i,4)=ResultKernelT2{i}.error(1);
    TableFAR(i,5)=ResultKernelSPE{i}.error(1);
    TableFAR(i,6)=ResultintegratedKernelPCA{i}.error(1);
    TableFAR(i,7)=ResultD{i}.error(1);
%     TableFAR(i,6)=ResultD_Whitening{i}.error(1);
    TableMAR(i,1)=ResultT2{i}.error(2);
    TableMAR(i,2)=ResultSPE{i}.error(2);
    TableMAR(i,3)=ResultintegratedPCA{i}.error(2);
    TableMAR(i,4)=ResultKernelT2{i}.error(2);
    TableMAR(i,5)=ResultKernelSPE{i}.error(2);
    TableMAR(i,6)=ResultintegratedKernelPCA{i}.error(2);
    TableMAR(i,7)=ResultD{i}.error(2);
%     TableMAR(i,6)=ResultD_Whitening{i}.error(2);
end







