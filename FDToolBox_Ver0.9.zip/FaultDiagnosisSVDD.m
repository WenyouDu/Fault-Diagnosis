function [model,DetectionResult] = FaultDiagnosisSVDD(train_data,train_label,test_data,test_label,Parameters)
%% Fault diagnosis using SVDD;
N=size(train_data,1);
tic
switch Parameters.search
    case 'off'        
        KernelParameter=num2str(Parameters.BestKernelParameter);
        BestVParameter=num2str(Parameters.BestVParameter);
    case 'on'   % mean criteria for bandwidth selection; Ref:"The Mean and Median Criteria for Kernel Bandwidth Selection for Support Vector Data Description" Equation 22
        sigma=std(train_data);
        delta=sqrt(2)*10^(3); % Ref page 4 Section II.C
        SearchedKernelParameter = (   (2*N*sum(sigma.^2))  /  ((N-1)*log((N-1)/(delta^2)))   )^.2 ;
        SearchedKernelParameter = 1/(2*SearchedKernelParameter^2);
        KernelParameter=num2str(SearchedKernelParameter);
        BestVParameter=num2str(Parameters.BestVParameter);
end

model = svmtrain(train_label,train_data,['-s 2 -g ',KernelParameter,' -n ',BestVParameter]);
[Ya,Yb,Yc] = svmpredict(test_label,test_data,model);

A=model.SVs;
alpha=model.sv_coef;
B=test_data;
lambda=model.Parameters(4);
K=MyGaussianKernel( A,B,lambda );
predict=-K'*alpha+model.rho;

%% transform the predict value to the distance from one point in feature space to the separation hypersphere.
% calculate the new control limit and statistic.
% ������Ҫ�ĵط�,
alpha=zeros(N,1);
alpha(model.sv_indices)=model.sv_coef;
K_N=MyGaussianKernel(train_data,train_data,lambda);
w=sqrt(alpha'*K_N*alpha);
ControlLimit=(1-model.rho/w);
Statistic=(predict/w+ControlLimit);
%% 

model.StatisticUperLimit=1;
model.StatisticLowerLimit=0;
model.train_data=train_data;

DetectionResult.Statistic=Statistic;
DetectionResult.ControlLimit=ControlLimit;
DetectionResult.BestParameter=KernelParameter;
DetectionResult.m=zeros(1,size(train_data,2));%%only used in PCA FD
toc
end