% ExperimentFaultDetectionChiangsDataSet
% there are total 21 faults in Chiang's Datase.
clc,clear,close all
FaultNums=2;
for i=1:FaultNums
    
    % config data for training and testing
    DatasetConfig.DatasetIndex=304;%'ICA_Test';303 % assign dataset
    DatasetConfig.TrainDataNumber=i;% fault index
    DatasetConfig.FaultMagnitude='MoreNormalData';% not used
    DatasetConfig.CentralizationOption='on';% wether centralize the dataset
    DatasetConfig.NormalizationOption='on';% wether normalize the dataset
    % obtain data
    [train_data,train_label,test_data,test_label]= PrepareData(DatasetConfig);
    
    
    %% PCA fault detection
    % set parameters
    Parameters.DiagnosisStstisticType='PCA_T2&SPE';% use the following two parameters instead of searching with algorithm
    Parameters.confidence_bound=0.99;
    Parameters.PC_CPV=0.95;
    Parameters.VarianceNormalize='on';
    % detection
    [modelPCA,DetectionResult] = FaultDiagnosisPCA(train_data,train_label,test_data,test_label,Parameters);
    ResultPCA{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.Statistic),1);
    idx_FaultT2=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.Statistic),1);
    idx_FaultSPE=find(DetectionResult.Statistic2>DetectionResult.ControlLimit2);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedPCA_PredictLabel=(DetectionResult.Statistic2>DetectionResult.ControlLimit2)|(DetectionResult.Statistic>DetectionResult.ControlLimit);
    idx_NormalIntegratedPCA=find(IntegratedPCA_PredictLabel==0);
    idx_FaultIntegratedPCA=find(IntegratedPCA_PredictLabel==1);
    PredictedLabelPCA_Total(idx_NormalIntegratedPCA)=1;
    PredictedLabelPCA_Total(idx_FaultIntegratedPCA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixKernelT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixKernelSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixKernelPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelPCA_Total );
    options=[];
    ResultT2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelT2{i}, options );
    ResultSPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelSPE{i}, options );
    ResultintegratedPCA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelPCA{i}, options );
    %% end of PCA fault detection
    
    %% ICA fault detection C2+ SPE
    
    Parameter.confidence_bound=0.99;
    Parameter.MaxPolynomialNumber=20;
    Parameter.fold=2;% the number of fold for polynoimal number selection
    Parameter.CPI=0.8;
    Parameter.BiasForBoxCox=500;
    Parameter.GDTmethod='BoxCox';% 'Polynomial' or 'BoxCox'
    % diagnosis with ica
    [model,DetectionResult] = FaultDiagnosisICA( train_data,train_label,test_data,test_label,Parameter);
    ResultICA1{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelC2=ones(length(DetectionResult.C2),1);
    idx_FaultC2=find(DetectionResult.C2>DetectionResult.C2c);
    PredictedLabelC2(idx_FaultC2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.SPE),1);
    idx_FaultSPE=find(DetectionResult.SPE>DetectionResult.SPEc);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedICA_PredictLabel=(DetectionResult.SPE>DetectionResult.SPEc)|(DetectionResult.C2>DetectionResult.C2c)';
    idx_NormalIntegratedICA=find(IntegratedICA_PredictLabel==0);
    idx_FaultIntegratedICA=find(IntegratedICA_PredictLabel==1);
    PredictedLabelICA_Total(idx_NormalIntegratedICA)=1;
    PredictedLabelICA_Total(idx_FaultIntegratedICA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixKernelT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelC2 );
    ConfusionMatrixKernelSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixKernelPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelICA_Total );
    options=[];
    ResultICA_C2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelT2{i}, options );
    ResultICA_SPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelSPE{i}, options );
    ResultintegratedICA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelPCA{i}, options );
    %% end of ICA fault detection
    
    %% ICA fault detection I2 + T2+ SPE
    PredictedLabelI2=ones(length(DetectionResult.Inew2),1);
    idx_FaultI2=find(DetectionResult.Inew2>DetectionResult.I2c);
    PredictedLabelI2(idx_FaultI2)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.T2),1);
    idx_FaultT2=find(DetectionResult.T2>DetectionResult.T2c);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.SPE),1);
    idx_FaultSPE=find(DetectionResult.SPE>DetectionResult.SPEc);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedICA_PredictLabel=(DetectionResult.SPE>DetectionResult.SPEc)|(DetectionResult.T2>DetectionResult.T2c)|(DetectionResult.Inew2>DetectionResult.I2c)';
    idx_NormalIntegratedICA=find(IntegratedICA_PredictLabel==0);
    idx_FaultIntegratedICA=find(IntegratedICA_PredictLabel==1);
    PredictedLabelICA_Total(idx_NormalIntegratedICA)=1;
    PredictedLabelICA_Total(idx_FaultIntegratedICA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixICA2I2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelI2 );
    ConfusionMatrixICA2T2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixICA2SPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixICA2Total{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelICA_Total );
    options=[];
    ResultICA2_I2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA2I2{i}, options );
    ResultICA2_T2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA2T2{i}, options );
    ResultICA2_SPE{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA2SPE{i}, options );
    ResultICA2_Total{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA2Total{i}, options );
    
    %% ICA fault detection IT2 + T2+ SPE
    PredictedLabelIT2=ones(length(DetectionResult.ITnew2),1);
    idx_FaultIT2=find(DetectionResult.ITnew2>DetectionResult.IT2c);
    PredictedLabelIT2(idx_FaultIT2)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.T2),1);
    idx_FaultT2=find(DetectionResult.T2>DetectionResult.T2c);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.SPE),1);
    idx_FaultSPE=find(DetectionResult.SPE>DetectionResult.SPEc);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedICA_PredictLabel=(DetectionResult.SPE>DetectionResult.SPEc)|(DetectionResult.T2>DetectionResult.T2c)|(DetectionResult.ITnew2>DetectionResult.IT2c)';
    idx_NormalIntegratedICA=find(IntegratedICA_PredictLabel==0);
    idx_FaultIntegratedICA=find(IntegratedICA_PredictLabel==1);
    PredictedLabelICA_Total(idx_NormalIntegratedICA)=1;
    PredictedLabelICA_Total(idx_FaultIntegratedICA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixICA3I2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelIT2 );
    ConfusionMatrixICA3T2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixICA3SPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixICA3Total{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelICA_Total );
    options=[];
    ResultICA3_I2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3I2{i}, options );
    ResultICA3_T2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3T2{i}, options );
    ResultICA3_SPE{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3SPE{i}, options );
    ResultICA3_Total{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3Total{i}, options );
    
    %% ICA fault detection I2+GDT_BoxCox + T2 + SPE
    
    
    %% ICA +SVDD fault detection
    % evaluation, prepare labels
    PredictedLabelD=ones(length(DetectionResult.DetectionResultSVDD.Statistic),1);
    idx_FaultD=find(DetectionResult.DetectionResultSVDD.Statistic>DetectionResult.DetectionResultSVDD.ControlLimit);
    PredictedLabelD(idx_FaultD)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.T2),1);
    idx_FaultT2=find(DetectionResult.T2>DetectionResult.T2c);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.SPE),1);
    idx_FaultSPE=find(DetectionResult.SPE>DetectionResult.SPEc);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedICA_SVDD_PredictLabel=(DetectionResult.SPE>DetectionResult.SPEc)|(DetectionResult.T2>DetectionResult.T2c)|(DetectionResult.DetectionResultSVDD.Statistic>DetectionResult.DetectionResultSVDD.ControlLimit);
    idx_NormalIntegratedICA_SVDD=find(IntegratedICA_SVDD_PredictLabel==0);
    idx_FaultIntegratedICA_SVDD=find(IntegratedICA_SVDD_PredictLabel==1);
    PredictedLabelICA_SVDD_Total(idx_NormalIntegratedICA_SVDD)=1;
    PredictedLabelICA_SVDD_Total(idx_FaultIntegratedICA_SVDD)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixICA3_SVDD_D{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelD );
    ConfusionMatrixICA3_SVDD_T2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixICA3_SVDD_SPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixICA3_SVDD_Total{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelICA_SVDD_Total );
    options=[];
    ResultICA3_SVDD_D{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3_SVDD_D{i}, options );
    ResultICA3_SVDD_T2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3_SVDD_T2{i}, options );
    ResultICA3_SVDD_SPE{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3_SVDD_SPE{i}, options );
    ResultICA3_SVDD_Total{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3_SVDD_Total{i}, options );
    %% end of ICA +SVDD fault detection
    
    %% ICA +GMM fault detection
    % evaluation, prepare labels
    PredictedLabelGMM=ones(length(DetectionResult.DetectionResultGMM.NLP_Predict),1);
    idx_FaultGMM=find(DetectionResult.DetectionResultGMM.NLP_Predict>DetectionResult.DetectionResultGMM.ControlLimit);
    PredictedLabelGMM(idx_FaultGMM)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.T2),1);
    idx_FaultT2=find(DetectionResult.T2>DetectionResult.T2c);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.SPE),1);
    idx_FaultSPE=find(DetectionResult.SPE>DetectionResult.SPEc);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedICA_GMM_PredictLabel=(DetectionResult.SPE>DetectionResult.SPEc)|(DetectionResult.T2>DetectionResult.T2c)|(DetectionResult.DetectionResultGMM.NLP_Predict>DetectionResult.DetectionResultGMM.ControlLimit);
    idx_NormalIntegratedICA_GMM=find(IntegratedICA_GMM_PredictLabel==0);
    idx_FaultIntegratedICA_GMM=find(IntegratedICA_GMM_PredictLabel==1);
    PredictedLabelICA_GMM_Total(idx_NormalIntegratedICA_GMM)=1;
    PredictedLabelICA_GMM_Total(idx_FaultIntegratedICA_GMM)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixICA3_GMM_NLP{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelGMM );
    ConfusionMatrixICA3_GMM_T2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixICA3_GMM_SPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixICA3_GMM_Total{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelICA_GMM_Total );
    options=[];
    ResultICA3_GMM_NLP{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3_GMM_NLP{i}, options );
    ResultICA3_GMM_T2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixICA3_GMM_T2{i}, options );
    ResultICA3_GMM_SPE{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3_GMM_SPE{i}, options );
    ResultICA3_GMM_Total{i}   = CalculateEvaluationIndicator(  ConfusionMatrixICA3_GMM_Total{i}, options );
    %% end of ICA +GMM fault detection
    
    
    
    disp(i)
    
end
for i=1:FaultNums
    TableFAR(i,1)=ResultT2{i}.error(1);
    TableFAR(i,2)=ResultSPE{i}.error(1);
    TableFAR(i,3)=ResultintegratedPCA{i}.error(1);
    TableFAR(i,4)=ResultICA_C2{i}.error(1);
    TableFAR(i,5)=ResultICA_SPE{i}.error(1);
    TableFAR(i,6)=ResultintegratedICA{i}.error(1);
    TableFAR(i,7)=ResultICA2_I2{i}.error(1);
    TableFAR(i,8)=ResultICA2_T2{i}.error(1);
    TableFAR(i,9)=ResultICA2_SPE{i}.error(1);
    TableFAR(i,10)=ResultICA2_Total{i}.error(1);
    TableFAR(i,11)=ResultICA3_SVDD_D{i}.error(1);
    TableFAR(i,12)=ResultICA3_SVDD_T2{i}.error(1);
    TableFAR(i,13)=ResultICA3_SVDD_SPE{i}.error(1);
    TableFAR(i,14)=ResultICA3_SVDD_Total{i}.error(1);  
    
    TableFAR(i,15)=ResultICA3_GMM_NLP{i}.error(1);
    TableFAR(i,16)=ResultICA3_GMM_T2{i}.error(1);
    TableFAR(i,17)=ResultICA3_GMM_SPE{i}.error(1);
    TableFAR(i,18)=ResultICA3_GMM_Total{i}.error(1);  
    
    %     TableMAR(i,1)=ResultT2{i}.error(2);
    %     TableMAR(i,2)=ResultSPE{i}.error(2);
    %     TableMAR(i,3)=ResultintegratedPCA{i}.error(2);
    %     TableMAR(i,4)=ResultICA_C2{i}.error(2);
    %     TableMAR(i,5)=ResultICA_SPE{i}.error(2);
    %     TableMAR(i,6)=ResultintegratedICA{i}.error(2);
    %     TableMAR(i,7)=ResultICA2_I2{i}.error(2);
    %     TableMAR(i,8)=ResultICA2_T2{i}.error(2);
    %     TableMAR(i,9)=ResultICA2_SPE{i}.error(2);
    %     TableMAR(i,10)=ResultICA2_Total{i}.error(2);
    %     TableMAR(i,11)=ResultICA3_I2{i}.error(2);
    %     TableMAR(i,12)=ResultICA3_T2{i}.error(2);
    %     TableMAR(i,13)=ResultICA3_SPE{i}.error(2);
    %     TableMAR(i,14)=ResultICA3_Total{i}.error(2);
    
    
    [d,n]=size(ResultICA1{1}.TransformedIC);
    nNormData=1:n;
    StdNormal=norminv((nNormData-0.5)/n);
    for i=1:d
        e_IC=corrcoef(StdNormal,sort(ResultICA1{1}.NewIC(i,:),'ascend'));
        e_GDT=corrcoef(StdNormal,sort(ResultICA1{1}.TransformedNewIC(i,:),'ascend'));
        TableCoefficient(1,i)=e_IC(1,2);
        TableCoefficient(2,i)=e_GDT(1,2);
    end
    
end



