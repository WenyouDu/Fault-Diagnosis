% ExperimentFaultDetectionRickersDataSet
% there are total 28 faults in Chiang's Datase.
clc,clear,close all
TotalFaultTypes=28;

%% train with more normal data
for i=1:TotalFaultTypes
    
    tStart=tic;
    DatasetConfig.DatasetIndex=303;% assign dataset
    DatasetConfig.TrainDataNumber=i;% assign fault
    DatasetConfig.FaultMagnitude='MoreNormalData1';% generate more traindata when set  'MoreNormalData'
    DatasetConfig.CentralizationOption='on';% wether centralize the dataset
    DatasetConfig.NormalizationOption='on';% wether normalize the dataset
    [train_data,train_label,test_data,test_label]= PrepareData(DatasetConfig);
    
    
     %% PCA fault detection
    % set parameters
    Parameters.DiagnosisStstisticType='PCA_T2&SPE';% use the following two parameters instead of searching with algorithm
    Parameters.confidence_bound=0.95;
    Parameters.PC_CPV=0.99;
    Parameters.VarianceNormalize='on';
    % detection
    [model,DetectionResult] = FaultDiagnosisPCA(train_data,train_label,test_data,test_label,Parameters);
    ResultPCA{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.Statistic),1);
    idx_FaultT2=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.Statistic),1);
    idx_FaultSPE=find(DetectionResult.Statistic2>DetectionResult.ControlLimit2);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedPCA_PredictLabel=(DetectionResult.Statistic2>DetectionResult.ControlLimit2)|(DetectionResult.Statistic>DetectionResult.ControlLimit);
    idx_NormalIntegratedPCA=find(IntegratedPCA_PredictLabel==0);   
    idx_FaultIntegratedPCA=find(IntegratedPCA_PredictLabel==1);
    PredictedLabelPCA_Total(idx_NormalIntegratedPCA)=1;
    PredictedLabelPCA_Total(idx_FaultIntegratedPCA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixKernelT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixKernelSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixKernelPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelPCA_Total );
    options=[];
    ResultT2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelT2{i}, options );
    ResultSPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelSPE{i}, options );
    ResultintegratedPCA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelPCA{i}, options );
    
    %% KPCA Fault Detection
    % set the parameters
    
    Parameters.DiagnosisStstisticType='KPCA_T2&SPE';% use the following two parameters instead of searching with algorithm
    Parameters.confidence_bound=0.999;
    Parameters.PC_CPV=0.95;
    Parameters.BestKernelParameter=10^(-4);
    % detection
    [model,DetectionResult] = FaultDiagnosisKPCA(train_data,train_label,test_data,test_label,Parameters);
    ResultKPCA{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelT2=ones(length(DetectionResult.Statistic),1);
    idx_FaultT2=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelT2(idx_FaultT2)=2;
    
    PredictedLabelSPE=ones(length(DetectionResult.Statistic),1);
    idx_FaultSPE=find(DetectionResult.Statistic2>DetectionResult.ControlLimit2);
    PredictedLabelSPE(idx_FaultSPE)=2;
    
    IntegratedPCA_PredictLabel=(DetectionResult.Statistic2>DetectionResult.ControlLimit2)|(DetectionResult.Statistic>DetectionResult.ControlLimit);
    idx_NormalIntegratedPCA=find(IntegratedPCA_PredictLabel==0);   
    idx_FaultIntegratedPCA=find(IntegratedPCA_PredictLabel==1);
    PredictedLabelPCA_Total(idx_NormalIntegratedPCA)=1;
    PredictedLabelPCA_Total(idx_FaultIntegratedPCA)=2;
    
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixKernelT2{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelT2 );
    ConfusionMatrixKernelSPE{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelSPE );
    ConfusionMatrixKernelPCA{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelPCA_Total );
    options=[];
    ResultKernelT2{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelT2{i}, options );
    ResultKernelSPE{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelSPE{i}, options );
    ResultintegratedKernelPCA{i}  = CalculateEvaluationIndicator(  ConfusionMatrixKernelPCA{i}, options );
    
    
   
    
    %% OC-SVM fault detection
    % set parameters
    Parameters.search='off';% use the following two parameters instead of searching with algorithm
    Parameters.BestKernelParameter=0.0001;
    Parameters.BestVParameter=0.01;
%     % whitening
%     C=(1/(size(train_data,1)-1))*train_data'*train_data;
%     [U,D,V]=svd(C);
%     dim=50;
%     train_data=train_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
%     test_data=test_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
    % detection
    [model,DetectionResult] = FaultDiagnosisSVDD(train_data,train_label,test_data,test_label,Parameters);
    ResultOCSVM{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelD=ones(length(DetectionResult.Statistic),1);
    idx_FaultD=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelD(idx_FaultD)=2;
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixD{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelD );
    options=[];
    ResultD{i}  = CalculateEvaluationIndicator(  ConfusionMatrixD{i}, options );
    
    
    %% whitened OC-SVM fault detection
    % set parameters
    Parameters.search='off';% use the following two parameters instead of searching with algorithm
    Parameters.BestKernelParameter=0.001;
    Parameters.BestVParameter=0.01;
    % whitening
    C=(1/(size(train_data,1)-1))*train_data'*train_data;
    [U,D,V]=svd(C);
    dim=50;
    train_data=train_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
    test_data=test_data*V(:,1:dim)*inv(sqrt(D(1:dim,1:dim)));
    % detection
    [model,DetectionResult] = FaultDiagnosisSVDD(train_data,train_label,test_data,test_label,Parameters);
    ResultOCSVM{i}=DetectionResult;
    % evaluation, prepare labels
    idx_normal=find(test_label==1);
    idx_fault=find(test_label~=1);
    GroundTruthLabel=[];GroundTruthLabel=[];
    GroundTruthLabel(idx_normal)=1;
    GroundTruthLabel(idx_fault)=2;
    
    PredictedLabelD=ones(length(DetectionResult.Statistic),1);
    idx_FaultD=find(DetectionResult.Statistic>DetectionResult.ControlLimit);
    PredictedLabelD(idx_FaultD)=2;
    % evaluation ,calculate ConfusionMatrix and FAR and MAR
    ConfusionMatrixD{i}  = CalculateConfusionMatrix( GroundTruthLabel,PredictedLabelD );
    options=[];
    ResultD_Whitened{i}  = CalculateEvaluationIndicator(  ConfusionMatrixD{i}, options );
    
    
    time_cost=toc(tStart);
    disp(['已完成第',num2str(i),'种故障检测，共计',num2str(TotalFaultTypes),'种。总计耗时：',num2str(time_cost),'seconds'])
    
end
for i=1:TotalFaultTypes
    TableFAR(i,1)=ResultT2{i}.error(1);
    TableFAR(i,2)=ResultSPE{i}.error(1);
    TableFAR(i,3)=ResultintegratedPCA{i}.error(1);
    TableFAR(i,4)=ResultKernelT2{i}.error(1);
    TableFAR(i,5)=ResultKernelSPE{i}.error(1);
    TableFAR(i,6)=ResultintegratedKernelPCA{i}.error(1);
    TableFAR(i,7)=ResultD{i}.error(1);
    TableFAR(i,8)=ResultD_Whitened{i}.error(1);
    TableMAR(i,1)=ResultT2{i}.error(2);
    TableMAR(i,2)=ResultSPE{i}.error(2);
    TableMAR(i,3)=ResultintegratedPCA{i}.error(2);
    TableMAR(i,4)=ResultKernelT2{i}.error(2);
    TableMAR(i,5)=ResultKernelSPE{i}.error(2);
    TableMAR(i,6)=ResultintegratedKernelPCA{i}.error(2);
    TableMAR(i,7)=ResultD{i}.error(2);
    TableMAR(i,8)=ResultD_Whitened{i}.error(2);
end