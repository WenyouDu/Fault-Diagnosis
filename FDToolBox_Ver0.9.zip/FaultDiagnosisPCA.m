function [model,DetectionResult] = FaultDiagnosisPCA(train_data,train_label,test_data,test_label,Parameters)
%% Fault Diagnosis using PCA
% train_data-> normal training data; test_data-> normal testing data; 
% Parameters.DiagnosisStstisticType-> using only T2 or using both T2 and
% SPE statistic to diagnose
% Parameters.PC_CPV-> if using both T2 and SPE, the PC numbers should be
% assigned with Cumulative Percentage Variance(CPV) criteria
% Parameters.confidence_bound-> confidence bound
% i.e. : Parameters.DiagnosisStstisticType=T2  PC_CPV=Parameters.PC_CPV=0.8 
% Parameters.confidence_bound=0.8 [model,DetectionResult] = FaultDiagnosisPCA(train_data,train_label,test_data,test_label,Parameters)

% assign parameters
DiagnosisStstisticType=Parameters.DiagnosisStstisticType;
PC_CPV=Parameters.PC_CPV;
confidence_bound=Parameters.confidence_bound;
VarianceNormalize=Parameters.VarianceNormalize;

% sub the train data of train data's mean value divide train data's standard variance.
x=train_data;
m = mean(x);
s = std(x)+eps*randn(1,size(x,2));% in case of zero
[ntrain ,varnum]= size(x);
x = x - repmat(m,ntrain,1);
switch VarianceNormalize
    case 'on'
        x=x./repmat(s,ntrain,1);
    case 'off'
end
% sub the test data of train data's mean value divide train data's standard variance.
xnew=test_data;
n = size(xnew,1);
xnew = xnew - repmat(m,n,1);
switch VarianceNormalize
    case 'on'
        xnew=xnew./repmat(s,n,1);
    case 'off'
end

% principal component analysis
%  [p,t,latent] = pca(x);
 [u1,lambda,v1]=svd(x'*x/(ntrain-1)) ; 
 latent=diag(lambda);p=v1;

switch DiagnosisStstisticType
    case 'PCA_T2&SPE' % monitor with hotelling's T2 and SPE statistic
        %��Find Principal Component Numbers according to CPV;
        cpv=0; % initialization
        for i=1:length(latent)
            cpv=cpv+latent(i);
            ccpv(i)=cpv/sum(latent);
        end
        PC_Nums=min(find(ccpv>=PC_CPV));
        
        %%Calculate the T2 control limit
        alpha = confidence_bound;
        a = PC_Nums;
        T2c = a*(ntrain-1)*(ntrain+1)/ntrain/(ntrain-a)*finv(alpha,a,ntrain-a);
        
        
        %%Calculate the SPE control limit
        %  ref  J.E. Jackson, G.S. Mudholkar, Control Procedures for Residuals Associated With Principal Component Analysis, Technometrics, 21 (1979) 341-349.
        for i = 1:3
            c(i) = sum(latent((a+1):varnum).^i);
        end
        h0 = 1 - 2*c(1)*c(3)/3/c(2)^2;
        ca = norminv(alpha,0,1);
        Qc = c(1)*(h0*ca*sqrt(2*c(2))/c(1) + 1 +c(2)*h0*(h0-1)/c(1)^2)^(1/h0);

        % calculate the new statistics
        T2 = zeros(n,1);
        Q = zeros(n,1);
        for i = 1:n
            T2(i) = xnew(i,:)*p(:,1:a)*inv(diag(latent(1:a)))*p(:,1:a)'*xnew(i,:)';
            Q(i) = ((eye(varnum) - p(:,1:a)*p(:,1:a)')*xnew(i,:)')' *  ((eye(varnum) - p(:,1:a)*p(:,1:a)')*xnew(i,:)');
        end
        
    case 'PCA_T2'  % monitor with only T2
        %monitor with all PCs
        PC_Nums=varnum;
        
        %%Calculate the T2 control limit
        alpha = confidence_bound;
        a = PC_Nums;
        T2c = a*(ntrain-1)*(ntrain+1)/ntrain/(ntrain-a)*finv(alpha,a,ntrain-a);
        
        %%monitor for new samples
        T2 = zeros(n,1);
        for i = 1:n
            T2(i) = xnew(i,:)*p(:,1:a)*inv(diag(latent(1:a)))*p(:,1:a)'*xnew(i,:)';
        end
        
        %%assign some value for SPE to keep the programme consistence.
        Q=zeros(1,n);
        Qc=0;
        
end

% Calculate the accuracy of T2
SignOfNegative=1;
SignOfPositive=-1;
T2Negative=T2(find(test_label==SignOfNegative));
T2Positive=T2(find(test_label==SignOfPositive));
TrueT2=(length(find(T2Negative<=T2c))+length(find(T2Positive>T2c)) );
TandP_T2=length(T2);
T2ACC=TrueT2/TandP_T2;
disp(['Accuracy of T^2 ststistic = ',num2str(T2ACC*100),'% (',num2str(TrueT2),'/',num2str(TandP_T2),') (classification)'])
% Calculate the accuracy of SPE
SPE_Negative=Q(find(test_label==SignOfNegative));
SPE_Positive=Q(find(test_label==SignOfPositive));
True_SPE=(length(find(SPE_Negative<=Qc))+length(find(SPE_Positive>Qc)) );
TandP_SPE=length(Q);
Q_ACC=True_SPE/TandP_SPE;
switch DiagnosisStstisticType
    case 'PCA_T2&SPE'
        disp(['Accuracy of SPE ststistic = ',num2str(Q_ACC*100),'% (',num2str(True_SPE),'/',num2str(TandP_SPE),') (classification)'])
    case 'PCA_T2'
        disp(['SPE is not calculated (classification)'])
end

% return results
model.m=m;
switch VarianceNormalize
    case 'on'
        model.s=s;
    case 'off'
        model.s=1;
end
model.p=p;
model.latent=latent;
model.PC_Nums=PC_Nums;

DetectionResult.Statistic=T2;
DetectionResult.Statistic2=Q;
DetectionResult.ControlLimit=T2c;
DetectionResult.ControlLimit2=Qc;
DetectionResult.m=m;


end









