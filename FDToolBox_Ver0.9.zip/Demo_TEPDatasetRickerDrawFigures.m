% Run this after Running Demo_TEPDatasetRicker.m;
for i=1:28
%% T2
Statistic=ResultPCA{1,i}.Statistic;
ControlLimit=ResultPCA{1,i}.ControlLimit;
figure,hold on,plot(Statistic,'b','linewidth',1)
line([0,length(Statistic)],[ControlLimit,ControlLimit],'LineWidth',2,'Color',[1 0 0])
legend 'T^2 Statistic' 'Control Limit'
% ���� ylabel
ylabel('Ststistics');
% ���� xlabel
xlabel('Samples');
box on
saveas(gcf, ['./Result/fault',num2str(i),'T^2'], 'png')
close all
%% SPE
Statistic=ResultPCA{1,i}.Statistic2;
ControlLimit=ResultPCA{1,i}.ControlLimit2;
figure,hold on,plot(Statistic,'b','linewidth',1)
line([0,length(Statistic)],[ControlLimit,ControlLimit],'LineWidth',2,'Color',[1 0 0])
legend 'SPE Statistic' 'Control Limit'
% ���� ylabel
ylabel('Ststistics');
% ���� xlabel
xlabel('Samples');
box on
saveas(gcf, ['./Result/fault',num2str(i),'SPE'], 'png')
close all
%%  kernel T2
Statistic=ResultKPCA{1,i}.Statistic;
ControlLimit=ResultKPCA{1,i}.ControlLimit;
figure,hold on,plot(Statistic,'b','linewidth',1)
line([0,length(Statistic)],[ControlLimit,ControlLimit],'LineWidth',2,'Color',[1 0 0])
legend 'kernel T^2 Statistic' 'Control Limit'
% ���� ylabel
ylabel('Ststistics');
% ���� xlabel
xlabel('Samples');
box on
saveas(gcf, ['./Result/fault',num2str(i),'kerlel T^2'], 'png')
close all

%% kernel SPE
Statistic=ResultKPCA{1,i}.Statistic2;
ControlLimit=ResultKPCA{1,i}.ControlLimit2;
figure,hold on,plot(Statistic,'b','linewidth',1)
line([0,length(Statistic)],[ControlLimit,ControlLimit],'LineWidth',2,'Color',[1 0 0])
legend 'kernel SPE Statistic' 'Control Limit'
% ���� ylabel
ylabel('Ststistics');
% ���� xlabel
xlabel('Samples');
box on
saveas(gcf, ['./Result/fault',num2str(i),'kernel SPE'], 'png')
close all

%% ocsvm
Statistic=ResultOCSVM{1,i}.Statistic;
ControlLimit=ResultOCSVM{1,i}.ControlLimit;
figure,hold on,plot(Statistic,'b','linewidth',1)
line([0,length(Statistic)],[ControlLimit,ControlLimit],'LineWidth',2,'Color',[1 0 0])
legend 'D Statistic' 'Control Limit'
% ���� ylabel
ylabel('Ststistics');
% ���� xlabel
% xlabel('Samples');
box on
saveas(gcf, ['./Result/fault',num2str(i),'OCSVM-D'], 'png')
close all
end